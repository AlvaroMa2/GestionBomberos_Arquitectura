<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Búsqueda</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
<a href="Leer.php" class="button">Ir a Leer.php</a>

<?php
include 'bd.php';
if (isset($_GET['nombre'])) {
    $nombre = $_GET['nombre'];

    $sql = "SELECT * FROM bomberos WHERE Nombre LIKE ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error al preparar la consulta: " . $conn->error);
    }

    $nombre_param = "%$nombre%";
    $stmt->bind_param("s", $nombre_param);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<h2 class='search-results-title'>Resultados de la búsqueda:</h2>";
    echo "<div class='content'>"; // Abre el contenedor para los resultados

    while ($row = $result->fetch_assoc()) {
        echo "<div class='card'>";
        echo "<h3>ID Bombero: " . htmlspecialchars($row['ID_Bombero']) . "</h3>";
        echo "<p>Nombre: " . htmlspecialchars($row['Nombre']) . "</p>";
        echo "<p>Teléfono: " . htmlspecialchars($row['Teléfono']) . "</p>";
        echo "</div>"; // Cierra el cuadro
    }

    echo "</div>"; // Cierra el contenedor
    $stmt->close();
    $conn->close();
} else {
    echo "<p class='error-message'>Ingrese un término de búsqueda válido.</p>";
}
?>
</body>
</html>
