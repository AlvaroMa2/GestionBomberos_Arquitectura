<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Navegación</title>
    <link rel="stylesheet" href="styleadmin.css">
</head>
<body>
    <div class="sidebar">
        <ul>
            <li><a href="crear.php">Agregar Voluntario</a></li>
            <li><a href="Leer.php">Buscar Voluntario</a></li>
            <li><a href="modificar.php">Modificar Voluntario</a></li>
            <li><a href="Eliminar.php">Eliminar Voluntario</a></li>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <li><a href="login.php">Salir</a></li>
        </ul>
    </div>
    <img alt="Cuerpo de Bomberos de Rancagua Logo" src="https://www.bomberosrancagua.cl/wp-content/uploads/2024/02/ok-LOGOS-142-CBR.png">  
</body>
</html>
