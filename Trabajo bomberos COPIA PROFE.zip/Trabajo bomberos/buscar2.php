<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Búsqueda</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
<a href="buscar.php" class="button">Regresar</a>

<?php
include 'bd.php';
if (isset($_GET['nombre'])) {
    $nombre = $_GET['nombre'];

    $sql = "SELECT * FROM bomberos WHERE Nombre LIKE ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error al preparar la consulta: " . $conn->error);
    }

    $nombre_param = "%$nombre%";
    $stmt->bind_param("s", $nombre_param);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<h2 class='search-results-title'>Resultados de la búsqueda:</h2>";
    echo "<div class='content'>";

    while ($row = $result->fetch_assoc()) {
        echo "<div class='card'>";
        echo "<h3>ID Bombero: " . htmlspecialchars($row['ID_Bombero']) . "</h3>";
        echo "<p>Nombre: " . htmlspecialchars($row['Nombre']) . "</p>";
        echo "<p>Teléfono: " . htmlspecialchars($row['Teléfono']) . "</p>";

        $imagePath = "Trabajo bomberos/" . htmlspecialchars($row['ID_Bombero']) . ".jpg";
        
        if (file_exists($imagePath)) {
            echo "<img src='$imagePath' alt='Foto de " . htmlspecialchars($row['Nombre']) . "' class='firefighter-photo'>";
        } else {
            echo "<p>Imagen no disponible</p>";
        }

        echo "</div>"; 
    }

    echo "</div>";
    $stmt->close();
    $conn->close();
} else {
    echo "<p class='error-message'>Ingrese un término de búsqueda válido.</p>";
}
?>

</body>
</html>