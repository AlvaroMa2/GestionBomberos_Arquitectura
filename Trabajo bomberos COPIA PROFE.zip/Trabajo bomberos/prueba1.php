<?php
session_start();

include 'bd.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista Cuartel</title>
    <link rel="stylesheet" href="style4ta.css">
</head>
<body>
    <header class="header">
        <div class="logo-container">
            <a href="login.php">
            <img src="logo1.png" alt="Logo del Cuartel" class="logo">
            <div class="cuartel-info"></a>
                <span>Cuartel 4ª</span>
            </div>
        </div>
        <div class="form-container">
            <form action="" method="get">
                <input type="text" id="personId" name="id" placeholder="Ingrese el ID">
                <button type="submit">Buscar</button>
            </form>
        </div>
        <div class="status">
            <div class="status-item">Q-4</div>
            <div class="status-item">RX-4</div>
            <div class="status-item">M-4</div>
        </div>
        <div class="info">
            <div id="clock"></div>
        </div>
    </header>

    <main>
    <section class="cards-grid" id="cardsGrid">
    <?php
        if (!isset($_SESSION['searched_ids'])) {
            $_SESSION['searched_ids'] = [];
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            if (is_numeric($id)) {
                if (in_array($id, $_SESSION['searched_ids'])) {
                    $_SESSION['searched_ids'] = array_diff($_SESSION['searched_ids'], [$id]);
                } else {
                    $sql = "SELECT * FROM bomberos WHERE ID_Bombero = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        $_SESSION['searched_ids'][] = $id;
                    } else {
                        echo '<div class="mensaje-error" id="mensajeError">No se encontró ningún bombero con ese ID.</div>';
                    }
                    $stmt->close();
                }
            } else {
                echo '<p>Por favor, ingrese un ID válido.</p>';
            }
        }

        foreach ($_SESSION['searched_ids'] as $searched_id) {
            $sql = "SELECT * FROM bomberos WHERE ID_Bombero = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $searched_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo '<div class="card" data-id="' . htmlspecialchars($row['ID_Bombero']) . '">';
                echo '<img src="' . htmlspecialchars($row['ID_Bombero']) . '.jpg" alt="Foto de ' . htmlspecialchars($row['Nombre']) . '">';
                echo '<h3>' . htmlspecialchars($row['Nombre']) . '</h3>';
                echo '<p>ID: ' . htmlspecialchars($row['ID_Bombero']) . '</p>';
                echo '<p>Operatividad: ' . htmlspecialchars($row['Operatividad']) . '</p>';
                echo '</div>';
            }
            $stmt->close();
        }
    ?>
            <script>
            setTimeout(function() {
                var mensaje = document.getElementById("mensajeError");
            if (mensaje) {
                mensaje.style.opacity = "0"; 
                setTimeout(function() {
                mensaje.style.display = "none"; 
                }, 500); 
                }
                }, 3000); 
        </script>

    </section>

        <div class="bottom-section">
            <div class="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3358.098197835186!2d-70.74648828494053!3d-34.16941098054761!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9665bff4c5ab30d7%3A0x3b589cf8cb73e40!2sCuartel%204%C2%AA%20Rancagua!5e0!3m2!1ses-419!2scl!4v1698721357797!5m2!1ses-419!2scl" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
            <div class="novedades">
                <h2>Novedades</h2>
                <div class="novedad-item"><span>Señalizar incendio en sector X</span><span>11:30</span></div>
                <div class="novedad-item"><span>Entrenamiento programado para el 5 de noviembre</span><span>09:00</span></div>
            </div>
        </div>
    </main>

    <script>
        setInterval(function() {
            const now = new Date();
            document.getElementById('clock').innerText = now.toLocaleTimeString();
        }, 1000);
    </script>
</body>
</html>
