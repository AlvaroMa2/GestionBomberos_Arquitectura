<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>emergencia</title>
    <link rel="stylesheet" href="stylecentral.css">
    <style>
        /* Contenedor centrado para la tabla */
.table-container {
    display: flex;
    justify-content: center; /* Centra la tabla horizontalmente */
    padding: 20px;
    width: 100%; /* Hace que el contenedor ocupe el 100% del ancho */
}

/* Ajuste de tamaño de la tabla */
table {
    background-color: #333;
    color: white;
    width: 60%; /* Ancho de la tabla reducido */
    max-width: 600px; /* Tamaño máximo para pantallas grandes */
    border-collapse: collapse;
    text-align: center; /* Centra el texto de las celdas */
}

/* Color de fondo de los encabezados */
table th {
    background-color: #444;
    color: #FFF;
    padding: 10px;
    border: 1px solid #555;
}

/* Color de fondo de las filas */
table td {
    background-color: #555;
    padding: 8px;
    border: 1px solid #666;
}

/* Color alternado para las filas */
table tr:nth-child(even) {
    background-color: #666;
}

table tr:hover {
    background-color: #777;
}

    </style>
</head>
<body>
<div class="sidebar">
        <ul>
            <li><a href="buscar.php">Buscar</a></li>
            <li><a href="mapa.php">Mapa</a></li>
            <li><a href="emergencia.php">Números de Emergencia</a></li>
            <li><a href="frecuencia.php">Frecuencias</a></li>
            <li><a href="zello.php">Zello</a></li>
            <li><a href="cuarteles.php">Cuarteles</a></li>
            <li><a href="maquinas.php">Máquinas disponibles</a></li>
            <li><a href="oficiales.php">Números Oficiales</a></li>
            <br><br>
            <li><a href="login.php">Salir</a></li>
        </ul>
    </div>
    <div class="table-container">
    <table>
        <tr>
            <th>Numero de Emergencia</th>
            <th>Descripción</th>
        </tr>
        <tr>
            <td>CONAF</td>
            <td>130</td>
        </tr>
        <tr>
            <td>SAMU</td>
            <td>131</td>
        </tr>
        <tr>
            <td>BOMBEROS</td>
            <td>132</td>
        </tr>
        <tr>
            <td>CARABINEROS</td>
            <td>133</td>
        </tr>
        <tr>
            <td>PDI</td>
            <td>134</td>
        </tr>
        <tr>
            <td>SOCORRO ANDINO</td>
            <td>136</td>
        </tr>
        <tr>
            <td>SALVAMENTO MARINO</td>
            <td>137</td>
        </tr>
        <tr>
            <td>BUSQUEDA Y SALVAMENTO AEREO</td>
            <td>138</td>
        </tr>
        <tr>
            <td>GOPE</td>
            <td>7228264060</td>
        </tr>
        <tr>
            <td>EMERGENCIAS</td>
            <td>911</td>
        </tr>
    </table>
    </div>
</body>
</html>